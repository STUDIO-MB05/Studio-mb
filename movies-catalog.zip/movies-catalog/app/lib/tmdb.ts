const BASE_URL = 'https://api.themoviedb.org/3'

function getApiKey() {
  const key = process.env.TMDB_API_KEY
  if (!key) throw new Error('TMDB_API_KEY is not set in environment variables')
  return key
}

async function fetchTMDB(path: string, params: Record<string, string> = {}) {
  const url = new URL(`${BASE_URL}${path}`)
  url.searchParams.set('api_key', getApiKey())
  url.searchParams.set('language', 'ka-GE')
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, v)
  }

  const res = await fetch(url.toString(), { next: { revalidate: 3600 } })
  if (!res.ok) throw new Error(`TMDB fetch failed: ${res.status}`)
  return res.json()
}

export async function getPopularMovies(page = 1) {
  return fetchTMDB('/movie/popular', { page: String(page) })
}

export async function getTopRatedMovies(page = 1) {
  return fetchTMDB('/movie/top_rated', { page: String(page) })
}

export async function getUpcomingMovies(page = 1) {
  return fetchTMDB('/movie/upcoming', { page: String(page) })
}

export async function getTrendingMovies() {
  return fetchTMDB('/trending/movie/week')
}

export async function getMovieDetails(id: string) {
  return fetchTMDB(`/movie/${id}`, {
    append_to_response: 'credits,videos,similar,recommendations',
  })
}

export async function searchMovies(query: string, page = 1) {
  return fetchTMDB('/search/movie', { query, page: String(page) })
}

export async function getGenres() {
  return fetchTMDB('/genre/movie/list')
}

export async function getMoviesByGenre(genreId: string, page = 1) {
  return fetchTMDB('/discover/movie', {
    with_genres: genreId,
    page: String(page),
    sort_by: 'popularity.desc',
  })
}
