export default function Loading() {
  return (
    <div className="max-w-7xl mx-auto px-6 pt-28 pb-24">
      {/* Title skeleton */}
      <div className="mb-12">
        <div className="skeleton h-4 w-24 rounded mb-3" />
        <div className="skeleton h-12 w-72 rounded-lg mb-4" />
        <div className="skeleton h-px w-32" />
      </div>

      {/* Grid skeleton */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="rounded-xl overflow-hidden">
            <div className="skeleton aspect-[2/3]" />
            <div className="p-3 bg-cinema-card">
              <div className="skeleton h-4 w-4/5 rounded mb-2" />
              <div className="skeleton h-3 w-1/3 rounded" />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
