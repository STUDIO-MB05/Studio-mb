import { getUpcomingMovies } from '../lib/tmdb'
import MovieCard from '../components/MovieCard'

export const metadata = { title: 'მალე კინოში — CinéVault' }

function Pagination({ page, totalPages, basePath }: { page: number; totalPages: number; basePath: string }) {
  const pages = buildPageList(page, totalPages)
  return (
    <div className="flex items-center justify-center gap-2 mt-16">
      {page > 1 && (
        <a href={`${basePath}?page=${page - 1}`} className="px-4 py-2 rounded-lg border border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold transition-colors font-body text-sm">← წინა</a>
      )}
      {pages.map((p, i) =>
        p === '...' ? <span key={`e-${i}`} className="text-cinema-muted px-2">…</span> : (
          <a key={p} href={`${basePath}?page=${p}`} className={`w-10 h-10 flex items-center justify-center rounded-lg border text-sm font-body transition-colors ${p === page ? 'border-cinema-gold bg-cinema-gold text-cinema-black font-semibold' : 'border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold'}`}>{p}</a>
        )
      )}
      {page < totalPages && (
        <a href={`${basePath}?page=${page + 1}`} className="px-4 py-2 rounded-lg border border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold transition-colors font-body text-sm">შემდეგი →</a>
      )}
    </div>
  )
}

function buildPageList(current: number, total: number): (number | '...')[] {
  const delta = 2
  const range: number[] = []
  const result: (number | '...')[] = []
  for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) range.push(i)
  if (range[0] > 2) result.push(1, '...')
  else result.push(1)
  result.push(...range)
  if (range[range.length - 1] < total - 1) result.push('...', total)
  else if (total > 1) result.push(total)
  return result
}

export default async function UpcomingPage({ searchParams }: { searchParams: { page?: string } }) {
  const page = Number(searchParams.page) || 1
  const data = await getUpcomingMovies(page)
  const totalPages = Math.min(data.total_pages, 500)

  return (
    <div className="max-w-7xl mx-auto px-6 pt-28 pb-24">
      <div className="mb-12">
        <p className="text-cinema-gold text-xs font-body tracking-[0.2em] uppercase mb-2">მალე</p>
        <h1 className="font-display text-5xl font-black text-cinema-text">მალე კინოში</h1>
        <div className="gold-line mt-4 w-32" />
        <p className="text-cinema-muted font-body mt-4">
          ახალი ფილმები, რომლებიც მალე ეკრანებზე გამოჩნდება.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
        {data.results.map((movie: any) => {
          const releaseDate = movie.release_date
            ? new Date(movie.release_date).toLocaleDateString('ka-GE', { day: 'numeric', month: 'long', year: 'numeric' })
            : null
          return (
            <div key={movie.id} className="relative">
              {releaseDate && (
                <div className="absolute bottom-12 left-0 right-0 z-10 text-center">
                  <span className="inline-block bg-cinema-black/90 text-cinema-gold text-xs font-body px-2 py-1 rounded-md">
                    📅 {releaseDate}
                  </span>
                </div>
              )}
              <MovieCard movie={movie} />
            </div>
          )
        })}
      </div>

      <Pagination page={page} totalPages={totalPages} basePath="/upcoming" />
    </div>
  )
}
