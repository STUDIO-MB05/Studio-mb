import { getMovieDetails } from '../../lib/tmdb'
import Image from 'next/image'
import Link from 'next/link'
import MovieCard from '../../components/MovieCard'
import { notFound } from 'next/navigation'

export async function generateMetadata({ params }: { params: { id: string } }) {
  try {
    const movie = await getMovieDetails(params.id)
    return { title: `${movie.title} — CinéVault` }
  } catch {
    return { title: 'ფილმი — CinéVault' }
  }
}

const CREW_ROLES = ['Director', 'Producer', 'Screenplay', 'Story']

export default async function MoviePage({ params }: { params: { id: string } }) {
  let movie: any
  try {
    movie = await getMovieDetails(params.id)
  } catch {
    notFound()
  }

  const backdropUrl = movie.backdrop_path
    ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}`
    : null
  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : null

  const director = movie.credits?.crew?.find((c: any) => c.job === 'Director')
  const topCrew = movie.credits?.crew
    ?.filter((c: any) => CREW_ROLES.includes(c.job))
    .slice(0, 6) || []
  const cast = movie.credits?.cast?.slice(0, 8) || []
  const trailer = movie.videos?.results?.find(
    (v: any) => v.type === 'Trailer' && v.site === 'YouTube'
  )
  const similar = [...(movie.recommendations?.results || []), ...(movie.similar?.results || [])]
    .filter((m: any, i: number, arr: any[]) => arr.findIndex((x) => x.id === m.id) === i)
    .slice(0, 10)

  const runtime = movie.runtime
    ? `${Math.floor(movie.runtime / 60)}სთ ${movie.runtime % 60}წთ`
    : null

  return (
    <div className="min-h-screen">
      {/* Backdrop */}
      <div className="relative h-[60vh] overflow-hidden">
        {backdropUrl && (
          <Image src={backdropUrl} alt={movie.title} fill priority className="object-cover" sizes="100vw" />
        )}
        <div className="hero-gradient absolute inset-0" />
        <div className="absolute inset-0 bg-cinema-black/40" />
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 -mt-40 relative z-10 pb-24">
        <div className="flex flex-col md:flex-row gap-10">

          {/* Poster */}
          <div className="flex-shrink-0">
            <div className="w-48 md:w-64 rounded-2xl overflow-hidden border border-cinema-border shadow-2xl">
              {posterUrl ? (
                <Image src={posterUrl} alt={movie.title} width={256} height={384} className="w-full" />
              ) : (
                <div className="aspect-[2/3] bg-cinema-card flex items-center justify-center">
                  <span className="text-6xl">🎬</span>
                </div>
              )}
            </div>
          </div>

          {/* Details */}
          <div className="flex-1 pt-8 md:pt-32">
            {/* Genres */}
            <div className="flex flex-wrap gap-2 mb-4">
              {movie.genres?.map((g: any) => (
                <span key={g.id} className="text-xs px-3 py-1 rounded-full border border-cinema-gold/30 text-cinema-gold font-body">
                  {g.name}
                </span>
              ))}
            </div>

            {/* Title */}
            <h1 className="font-display text-4xl md:text-6xl font-black text-cinema-text mb-2 leading-tight">
              {movie.title}
            </h1>
            {movie.tagline && (
              <p className="font-display italic text-cinema-gold/70 text-lg mb-6">&ldquo;{movie.tagline}&rdquo;</p>
            )}

            {/* Meta row */}
            <div className="flex flex-wrap items-center gap-6 mb-8 text-sm font-body text-cinema-muted">
              {movie.vote_average > 0 && (
                <div className="flex items-center gap-2">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="#c9a84c">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                  <span className="text-cinema-gold font-semibold text-base">{movie.vote_average.toFixed(1)}</span>
                  <span className="text-cinema-muted">({movie.vote_count?.toLocaleString()} ხმა)</span>
                </div>
              )}
              {movie.release_date && <span>{new Date(movie.release_date).getFullYear()}</span>}
              {runtime && <span>{runtime}</span>}
              {director && <span>რეჟ. <strong className="text-cinema-text">{director.name}</strong></span>}
            </div>

            {/* Overview */}
            <p className="text-cinema-text/80 font-body leading-relaxed text-base max-w-2xl mb-8">
              {movie.overview || 'აღწერა არ არის ხელმისაწვდომი.'}
            </p>

            {/* Trailer button */}
            {trailer && (
              <a
                href={`https://www.youtube.com/watch?v=${trailer.key}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 border border-cinema-gold text-cinema-gold hover:bg-cinema-gold hover:text-cinema-black font-body font-semibold px-6 py-3 rounded-xl transition-all group"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M8 5v14l11-7z" />
                </svg>
                ტრეილერის ყურება
              </a>
            )}
          </div>
        </div>

        {/* Divider */}
        <div className="gold-line my-16" />

        {/* Cast */}
        {cast.length > 0 && (
          <section className="mb-16">
            <h2 className="font-display text-2xl font-bold text-cinema-text mb-6">მსახიობები</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-4 stagger">
              {cast.map((person: any) => {
                const profileUrl = person.profile_path
                  ? `https://image.tmdb.org/t/p/w185${person.profile_path}`
                  : null
                return (
                  <div key={person.id} className="text-center group">
                    <div className="w-full aspect-square rounded-full overflow-hidden border-2 border-cinema-border group-hover:border-cinema-gold transition-colors mb-2 mx-auto" style={{ maxWidth: 80 }}>
                      {profileUrl ? (
                        <Image src={profileUrl} alt={person.name} width={80} height={80} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-cinema-card flex items-center justify-center text-2xl">👤</div>
                      )}
                    </div>
                    <p className="text-xs font-body font-medium text-cinema-text truncate">{person.name}</p>
                    <p className="text-xs font-body text-cinema-muted truncate">{person.character}</p>
                  </div>
                )
              })}
            </div>
          </section>
        )}

        {/* Crew */}
        {topCrew.length > 0 && (
          <section className="mb-16">
            <h2 className="font-display text-2xl font-bold text-cinema-text mb-6">შემოქმედები</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {topCrew.map((person: any) => (
                <div key={`${person.id}-${person.job}`} className="bg-cinema-card rounded-xl p-4 border border-cinema-border">
                  <p className="text-xs text-cinema-gold font-body mb-1">{person.job}</p>
                  <p className="text-cinema-text font-body font-medium">{person.name}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Similar Movies */}
        {similar.length > 0 && (
          <section>
            <h2 className="font-display text-3xl font-bold text-cinema-text mb-8">მსგავსი ფილმები</h2>
            <div className="gold-line mb-8 w-24" />
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
              {similar.map((m: any) => <MovieCard key={m.id} movie={m} />)}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
