import { searchMovies } from '../lib/tmdb'
import MovieCard from '../components/MovieCard'
import Link from 'next/link'

export function generateMetadata({ searchParams }: { searchParams: { q?: string } }) {
  return { title: searchParams.q ? `"${searchParams.q}" — CinéVault` : 'ძიება — CinéVault' }
}

function Pagination({ page, totalPages, query }: { page: number; totalPages: number; query: string }) {
  const pages = buildPageList(page, totalPages)
  const base = `/search?q=${encodeURIComponent(query)}`
  return (
    <div className="flex items-center justify-center gap-2 mt-16">
      {page > 1 && (
        <a href={`${base}&page=${page - 1}`} className="px-4 py-2 rounded-lg border border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold transition-colors font-body text-sm">← წინა</a>
      )}
      {pages.map((p, i) =>
        p === '...' ? <span key={`e-${i}`} className="text-cinema-muted px-2">…</span> : (
          <a key={p} href={`${base}&page=${p}`} className={`w-10 h-10 flex items-center justify-center rounded-lg border text-sm font-body transition-colors ${p === page ? 'border-cinema-gold bg-cinema-gold text-cinema-black font-semibold' : 'border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold'}`}>{p}</a>
        )
      )}
      {page < totalPages && (
        <a href={`${base}&page=${page + 1}`} className="px-4 py-2 rounded-lg border border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold transition-colors font-body text-sm">შემდეგი →</a>
      )}
    </div>
  )
}

function buildPageList(current: number, total: number): (number | '...')[] {
  const delta = 2
  const range: number[] = []
  const result: (number | '...')[] = []
  for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) range.push(i)
  if (range[0] > 2) result.push(1, '...')
  else result.push(1)
  result.push(...range)
  if (range[range.length - 1] < total - 1) result.push('...', total)
  else if (total > 1) result.push(total)
  return result
}

export default async function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string; page?: string }
}) {
  const query = searchParams.q?.trim() || ''
  const page = Number(searchParams.page) || 1

  if (!query) {
    return (
      <div className="max-w-7xl mx-auto px-6 pt-40 pb-24 text-center">
        <p className="font-display text-6xl mb-6">🔍</p>
        <h1 className="font-display text-4xl font-bold text-cinema-text mb-4">ფილმის ძიება</h1>
        <p className="text-cinema-muted font-body">გამოიყენე ნავიგაციის საძიებო ველი ზევით</p>
      </div>
    )
  }

  const data = await searchMovies(query, page)
  const movies = data.results || []
  const totalPages = Math.min(data.total_pages || 1, 500)
  const total = data.total_results || 0

  return (
    <div className="max-w-7xl mx-auto px-6 pt-28 pb-24">
      <div className="mb-12">
        <p className="text-cinema-gold text-xs font-body tracking-[0.2em] uppercase mb-2">ძიების შედეგები</p>
        <h1 className="font-display text-4xl md:text-5xl font-black text-cinema-text">
          &ldquo;<span className="text-cinema-gold">{query}</span>&rdquo;
        </h1>
        <div className="gold-line mt-4 w-32" />
        <p className="text-cinema-muted font-body mt-3">
          {total > 0 ? `${total.toLocaleString()} შედეგი ნაპოვნია` : 'შედეგი ვერ მოიძებნა'}
        </p>
      </div>

      {movies.length === 0 ? (
        <div className="text-center py-24">
          <p className="text-6xl mb-6">🎬</p>
          <p className="font-display text-2xl text-cinema-text mb-3">ვერ მოიძებნა</p>
          <p className="text-cinema-muted font-body mb-8">სცადე სხვა საძიებო სიტყვა</p>
          <Link href="/" className="text-cinema-gold hover:text-cinema-gold-light transition-colors font-body">
            ← მთავარ გვერდზე დაბრუნება
          </Link>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
            {movies.map((movie: any) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>
          {totalPages > 1 && (
            <Pagination page={page} totalPages={totalPages} query={query} />
          )}
        </>
      )}
    </div>
  )
}
