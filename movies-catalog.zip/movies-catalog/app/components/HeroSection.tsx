import Image from 'next/image'
import Link from 'next/link'

interface Movie {
  id: number
  title: string
  backdrop_path: string | null
  poster_path: string | null
  overview: string
  vote_average: number
  release_date: string
  genre_ids?: number[]
}

const GENRES: Record<number, string> = {
  28: 'საბრძოლო',
  12: 'თავგადასავალი',
  16: 'ანიმაცია',
  35: 'კომედია',
  80: 'კრიმინალი',
  99: 'დოკუმენტური',
  18: 'დრამა',
  10751: 'საოჯახო',
  14: 'ფანტაზია',
  36: 'ისტორიული',
  27: 'საშინელება',
  10402: 'მუსიკალური',
  9648: 'მისტიკა',
  10749: 'სასიყვარულო',
  878: 'ფანტასტიკა',
  10770: 'ტელეფილმი',
  53: 'თრილერი',
  10752: 'საომარი',
  37: 'ვესტერნი',
}

export default function HeroSection({ movie }: { movie: Movie }) {
  const backdropUrl = movie.backdrop_path
    ? `https://image.tmdb.org/t/p/original${movie.backdrop_path}`
    : null
  const year = new Date(movie.release_date).getFullYear()
  const rating = movie.vote_average.toFixed(1)
  const genres = (movie.genre_ids || []).slice(0, 3).map((id) => GENRES[id]).filter(Boolean)

  return (
    <div className="relative h-[90vh] min-h-[600px] overflow-hidden">
      {/* Backdrop */}
      {backdropUrl && (
        <div className="absolute inset-0">
          <Image
            src={backdropUrl}
            alt={movie.title}
            fill
            priority
            className="object-cover"
            sizes="100vw"
          />
        </div>
      )}

      {/* Gradients */}
      <div className="hero-gradient absolute inset-0" />
      <div className="hero-gradient-side absolute inset-0" />

      {/* Content */}
      <div className="absolute bottom-0 left-0 right-0 px-6 pb-16 max-w-7xl mx-auto">
        <div
          className="max-w-xl"
          style={{ animation: 'fadeUp 0.8s ease 0.2s both' }}
        >
          {/* Label */}
          <div className="flex items-center gap-3 mb-4">
            <span className="text-xs font-body font-medium tracking-[0.2em] text-cinema-gold uppercase">
              დღის რჩეული
            </span>
            <div className="h-px w-12 bg-cinema-gold/40" />
          </div>

          {/* Title */}
          <h1 className="font-display text-5xl md:text-7xl font-black text-white leading-tight mb-4">
            {movie.title}
          </h1>

          {/* Meta */}
          <div className="flex items-center gap-4 mb-4">
            <div className="flex items-center gap-1.5">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="#c9a84c">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
              <span className="text-cinema-gold font-medium font-body">{rating}</span>
            </div>
            <span className="text-cinema-muted text-sm">·</span>
            <span className="text-cinema-text/70 text-sm font-body">{year}</span>
            {genres.length > 0 && (
              <>
                <span className="text-cinema-muted text-sm">·</span>
                <div className="flex gap-2">
                  {genres.map((g) => (
                    <span
                      key={g}
                      className="text-xs px-2 py-0.5 rounded-full border border-cinema-gold/30 text-cinema-gold/80 font-body"
                    >
                      {g}
                    </span>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Overview */}
          <p className="text-cinema-text/70 text-sm font-body leading-relaxed mb-8 line-clamp-3 max-w-md">
            {movie.overview}
          </p>

          {/* CTA */}
          <Link
            href={`/movie/${movie.id}`}
            className="inline-flex items-center gap-3 bg-cinema-gold text-cinema-black font-body font-semibold px-8 py-3.5 rounded-xl hover:bg-cinema-gold-light transition-colors group"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M8 5v14l11-7z" />
            </svg>
            დეტალების ნახვა
            <span className="transition-transform group-hover:translate-x-1">→</span>
          </Link>
        </div>
      </div>
    </div>
  )
}
