'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState, useEffect, useRef } from 'react'

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [scrolled, setScrolled] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query.trim())}`)
      setSearchOpen(false)
      setQuery('')
    }
  }

  useEffect(() => {
    if (searchOpen) inputRef.current?.focus()
  }, [searchOpen])

  const navLinks = [
    { href: '/', label: 'მთავარი' },
    { href: '/popular', label: 'პოპულარული' },
    { href: '/top-rated', label: 'საუკეთესო' },
    { href: '/upcoming', label: 'მალე' },
  ]

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-cinema-black/95 backdrop-blur-md border-b border-cinema-border'
          : 'bg-gradient-to-b from-cinema-black/80 to-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-3 group">
          <span className="font-display text-2xl font-bold text-cinema-gold group-hover:text-cinema-gold-light transition-colors">
            CinéVault
          </span>
        </Link>

        {/* Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`text-sm font-body font-medium tracking-wide transition-colors relative group ${
                pathname === link.href
                  ? 'text-cinema-gold'
                  : 'text-cinema-muted hover:text-cinema-text'
              }`}
            >
              {link.label}
              {pathname === link.href && (
                <span className="absolute -bottom-1 left-0 right-0 h-px bg-cinema-gold" />
              )}
            </Link>
          ))}
        </div>

        {/* Search */}
        <div className="flex items-center gap-4">
          {searchOpen ? (
            <form onSubmit={handleSearch} className="flex items-center">
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ფილმის ძიება..."
                className="bg-cinema-card border border-cinema-gold/40 rounded-lg px-4 py-2 text-sm text-cinema-text placeholder-cinema-muted focus:outline-none focus:border-cinema-gold w-64 font-body transition-all"
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="ml-2 text-cinema-muted hover:text-cinema-text transition-colors"
              >
                ✕
              </button>
            </form>
          ) : (
            <button
              onClick={() => setSearchOpen(true)}
              className="text-cinema-muted hover:text-cinema-gold transition-colors p-2"
              aria-label="ძიება"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" />
                <path d="m21 21-4.35-4.35" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </nav>
  )
}
