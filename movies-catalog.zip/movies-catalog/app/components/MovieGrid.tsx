import MovieCard from './MovieCard'

interface Movie {
  id: number
  title: string
  poster_path: string | null
  vote_average: number
  release_date: string
  genre_ids?: number[]
  overview?: string
}

export default function MovieGrid({
  movies,
  title,
}: {
  movies: Movie[]
  title?: string
}) {
  return (
    <section>
      {title && (
        <div className="mb-8">
          <h2 className="font-display text-3xl font-bold text-cinema-text">{title}</h2>
          <div className="gold-line mt-3 w-24" />
        </div>
      )}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
        {movies.map((movie) => (
          <MovieCard key={movie.id} movie={movie} />
        ))}
      </div>
    </section>
  )
}
