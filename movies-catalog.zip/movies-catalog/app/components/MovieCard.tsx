import Link from 'next/link'
import Image from 'next/image'

interface Movie {
  id: number
  title: string
  poster_path: string | null
  vote_average: number
  release_date: string
  genre_ids?: number[]
  overview?: string
}

export default function MovieCard({ movie }: { movie: Movie }) {
  const year = movie.release_date ? new Date(movie.release_date).getFullYear() : ''
  const rating = movie.vote_average ? movie.vote_average.toFixed(1) : 'N/A'
  const posterUrl = movie.poster_path
    ? `https://image.tmdb.org/t/p/w500${movie.poster_path}`
    : null

  const ratingColor =
    parseFloat(rating) >= 7.5
      ? 'text-cinema-gold'
      : parseFloat(rating) >= 6
      ? 'text-yellow-500'
      : 'text-cinema-muted'

  return (
    <Link href={`/movie/${movie.id}`} className="block group">
      <div className="movie-card relative rounded-xl overflow-hidden bg-cinema-card border border-cinema-border hover:border-cinema-gold/40 transition-colors">
        {/* Poster */}
        <div className="relative aspect-[2/3] overflow-hidden">
          {posterUrl ? (
            <Image
              src={posterUrl}
              alt={movie.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-cinema-deep">
              <span className="font-display text-cinema-muted text-4xl">🎬</span>
            </div>
          )}

          {/* Overlay on hover */}
          <div className="card-overlay absolute inset-0 bg-gradient-to-t from-cinema-black via-cinema-black/60 to-transparent flex flex-col justify-end p-4">
            <p className="text-xs text-cinema-text/80 line-clamp-3 font-body leading-relaxed">
              {movie.overview}
            </p>
          </div>

          {/* Rating badge */}
          <div className="absolute top-3 right-3 bg-cinema-black/80 backdrop-blur-sm rounded-lg px-2 py-1 flex items-center gap-1">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="#c9a84c">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
            <span className={`text-xs font-medium ${ratingColor}`}>{rating}</span>
          </div>
        </div>

        {/* Info */}
        <div className="p-3">
          <h3 className="font-display text-sm font-semibold text-cinema-text truncate group-hover:text-cinema-gold transition-colors">
            {movie.title}
          </h3>
          <p className="text-xs text-cinema-muted mt-1 font-body">{year}</p>
        </div>
      </div>
    </Link>
  )
}
