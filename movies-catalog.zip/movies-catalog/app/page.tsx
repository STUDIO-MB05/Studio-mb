import { getTrendingMovies, getTopRatedMovies, getUpcomingMovies } from './lib/tmdb'
import HeroSection from './components/HeroSection'
import MovieCard from './components/MovieCard'
import Link from 'next/link'

export default async function HomePage() {
  const [trending, topRated, upcoming] = await Promise.all([
    getTrendingMovies(),
    getTopRatedMovies(),
    getUpcomingMovies(),
  ])

  const hero = trending.results[0]

  return (
    <div>
      <HeroSection movie={hero} />
      <div className="max-w-7xl mx-auto px-6 py-16 space-y-20">

        <section>
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-display text-3xl font-bold text-cinema-text">ტრენდული ამ კვირაში</h2>
              <div className="gold-line mt-3 w-24" />
            </div>
            <Link href="/popular" className="text-cinema-gold hover:text-cinema-gold-light transition-colors text-sm font-body flex items-center gap-1">ყველა <span>→</span></Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
            {trending.results.slice(0, 10).map((movie: any) => <MovieCard key={movie.id} movie={movie} />)}
          </div>
        </section>

        <section>
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-display text-3xl font-bold text-cinema-text">ყველა დროის საუკეთესო</h2>
              <div className="gold-line mt-3 w-24" />
            </div>
            <Link href="/top-rated" className="text-cinema-gold hover:text-cinema-gold-light transition-colors text-sm font-body flex items-center gap-1">ყველა <span>→</span></Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
            {topRated.results.slice(0, 10).map((movie: any) => <MovieCard key={movie.id} movie={movie} />)}
          </div>
        </section>

        <section>
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="font-display text-3xl font-bold text-cinema-text">მალე კინოში</h2>
              <div className="gold-line mt-3 w-24" />
            </div>
            <Link href="/upcoming" className="text-cinema-gold hover:text-cinema-gold-light transition-colors text-sm font-body flex items-center gap-1">ყველა <span>→</span></Link>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
            {upcoming.results.slice(0, 10).map((movie: any) => <MovieCard key={movie.id} movie={movie} />)}
          </div>
        </section>

      </div>
    </div>
  )
}
