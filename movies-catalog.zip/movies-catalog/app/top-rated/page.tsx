import { getTopRatedMovies } from '../lib/tmdb'
import MovieCard from '../components/MovieCard'

export const metadata = { title: 'საუკეთესო ფილმები — CinéVault' }

function Pagination({
  page,
  totalPages,
  basePath,
}: {
  page: number
  totalPages: number
  basePath: string
}) {
  const pages = buildPageList(page, totalPages)
  return (
    <div className="flex items-center justify-center gap-2 mt-16">
      {page > 1 && (
        <a href={`${basePath}?page=${page - 1}`} className="px-4 py-2 rounded-lg border border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold transition-colors font-body text-sm">
          ← წინა
        </a>
      )}
      {pages.map((p, i) =>
        p === '...' ? (
          <span key={`e-${i}`} className="text-cinema-muted px-2">…</span>
        ) : (
          <a key={p} href={`${basePath}?page=${p}`} className={`w-10 h-10 flex items-center justify-center rounded-lg border text-sm font-body transition-colors ${p === page ? 'border-cinema-gold bg-cinema-gold text-cinema-black font-semibold' : 'border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold'}`}>
            {p}
          </a>
        )
      )}
      {page < totalPages && (
        <a href={`${basePath}?page=${page + 1}`} className="px-4 py-2 rounded-lg border border-cinema-border text-cinema-muted hover:border-cinema-gold hover:text-cinema-gold transition-colors font-body text-sm">
          შემდეგი →
        </a>
      )}
    </div>
  )
}

function buildPageList(current: number, total: number): (number | '...')[] {
  const delta = 2
  const range: number[] = []
  const result: (number | '...')[] = []
  for (let i = Math.max(2, current - delta); i <= Math.min(total - 1, current + delta); i++) range.push(i)
  if (range[0] > 2) result.push(1, '...')
  else result.push(1)
  result.push(...range)
  if (range[range.length - 1] < total - 1) result.push('...', total)
  else if (total > 1) result.push(total)
  return result
}

export default async function TopRatedPage({ searchParams }: { searchParams: { page?: string } }) {
  const page = Number(searchParams.page) || 1
  const data = await getTopRatedMovies(page)
  const totalPages = Math.min(data.total_pages, 500)

  return (
    <div className="max-w-7xl mx-auto px-6 pt-28 pb-24">
      <div className="mb-12">
        <p className="text-cinema-gold text-xs font-body tracking-[0.2em] uppercase mb-2">კატალოგი</p>
        <h1 className="font-display text-5xl font-black text-cinema-text">ყველა დროის საუკეთესო</h1>
        <div className="gold-line mt-4 w-32" />
        <p className="text-cinema-muted font-body mt-4 max-w-xl">
          კინემატოგრაფის ისტორიაში ყველაზე მაღლა შეფასებული შედევრები — გახდი კინომანი.
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 stagger">
        {data.results.map((movie: any, i: number) => (
          <div key={movie.id} className="relative">
            {page === 1 && i < 3 && (
              <div className="absolute -top-3 -left-2 z-10 w-8 h-8 rounded-full bg-cinema-gold flex items-center justify-center font-display font-black text-cinema-black text-sm shadow-lg">
                {i + 1}
              </div>
            )}
            <MovieCard movie={movie} />
          </div>
        ))}
      </div>

      <Pagination page={page} totalPages={totalPages} basePath="/top-rated" />
    </div>
  )
}
