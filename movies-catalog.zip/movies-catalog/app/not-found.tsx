import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
      <p className="font-display text-[8rem] font-black text-cinema-border leading-none mb-4 select-none">
        404
      </p>
      <h1 className="font-display text-3xl font-bold text-cinema-text mb-4">
        გვერდი ვერ მოიძებნა
      </h1>
      <p className="text-cinema-muted font-body mb-10 max-w-sm">
        ეს ფილმი ან გვერდი არ არსებობს. შესაძლოა წაიშალა ან გადავიდა.
      </p>
      <Link
        href="/"
        className="inline-flex items-center gap-2 bg-cinema-gold text-cinema-black font-body font-semibold px-8 py-3.5 rounded-xl hover:bg-cinema-gold-light transition-colors"
      >
        ← მთავარ გვერდზე
      </Link>
    </div>
  )
}
