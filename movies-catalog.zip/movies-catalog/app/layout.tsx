import type { Metadata } from 'next'
import './globals.css'
import Navbar from './components/Navbar'

export const metadata: Metadata = {
  title: 'CinéVault — ფილმების კატალოგი',
  description: 'აღმოაჩინე საუკეთესო ფილმები, სერიალები და კინემატოგრაფიული შედევრები',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ka">
      <body className="noise min-h-screen bg-cinema-black">
        <Navbar />
        <main>{children}</main>
        <footer className="border-t border-cinema-border mt-24 py-12 text-center">
          <p className="font-display text-2xl text-cinema-gold mb-2">CinéVault</p>
          <p className="text-cinema-muted text-sm font-body">
            მონაცემები მოწოდებულია{' '}
            <a
              href="https://www.themoviedb.org"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cinema-gold hover:text-cinema-gold-light transition-colors"
            >
              TMDB
            </a>
            -ის მიერ
          </p>
        </footer>
      </body>
    </html>
  )
}
