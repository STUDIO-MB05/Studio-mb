# 🎬 CinéVault — ფილმების კატალოგი

პროფესიონალური ფილმების კატალოგი, Next.js 14-ზე აგებული, TMDB API-ს გამოყენებით.

## ✨ ფუნქციები

- 🏠 **მთავარი გვერდი** — ჰეროს სექცია + ტრენდული, საუკეთესო და მომავალი ფილმები
- 🎬 **ფილმის დეტალები** — პოსტერი, ბექდროპი, ტრეილერი, მსახიობები, მსგავსი ფილმები
- 🔍 **ძიება** — სახელით ძიება პაგინაციით
- 📈 **პოპულარული** — პოპულარული ფილმები გვერდ-გვერდ
- ⭐ **საუკეთესო** — ყველა დროის TOP ფილმები
- 🗓 **მალე** — მომავალი პრემიერები
- 📱 **Responsive** — მობილური, პლანშეტი, დესკტოპი

## 🚀 გაშვება

### 1. TMDB API Key-ის მიღება

1. გადადი [themoviedb.org/signup](https://www.themoviedb.org/signup)
2. შექმენი ანგარიში
3. Settings → API → Request an API Key
4. API Key-ს დაიმახსოვრე

### 2. პროექტის გაშვება ლოკალურად

```bash
# npm პაკეტების დაყენება
npm install

# .env.local ფაილის შექმნა
cp .env.local.example .env.local

# .env.local-ში შეიყვანე შენი API key:
# TMDB_API_KEY=შენი_api_გასაღები

# Dev server-ის გაშვება
npm run dev
```

გახსენი [http://localhost:3000](http://localhost:3000)

### 3. Vercel-ზე Deploy

#### ვარიანტი A: GitHub → Vercel (რეკომენდებული)

```bash
# 1. GitHub-ზე ატვირთე პროექტი
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/შენი-username/movies-catalog.git
git push -u origin main

# 2. vercel.com-ზე:
# → "New Project" → GitHub repo-ს import
# → Environment Variables-ში დაამატე:
#    TMDB_API_KEY = შენი_key
# → Deploy!
```

#### ვარიანტი B: Vercel CLI

```bash
npm install -g vercel
vercel login
vercel

# Deploy-ის დროს Environment Variable-ი დაამატე:
# TMDB_API_KEY → შენი key
```

## 📁 სტრუქტურა

```
movies-catalog/
├── app/
│   ├── layout.tsx          ← Root layout + Navbar + Footer
│   ├── page.tsx            ← მთავარი გვერდი
│   ├── loading.tsx         ← Loading skeleton
│   ├── not-found.tsx       ← 404 გვერდი
│   ├── globals.css         ← დიზაინ სისტემა
│   ├── lib/
│   │   └── tmdb.ts         ← TMDB API helper
│   ├── components/
│   │   ├── Navbar.tsx      ← ნავიგაცია
│   │   ├── HeroSection.tsx ← ჰეროს სექცია
│   │   ├── MovieCard.tsx   ← ფილმის ბარათი
│   │   └── MovieGrid.tsx   ← ბარათების გრიდი
│   ├── movie/[id]/
│   │   └── page.tsx        ← ფილმის დეტალები
│   ├── popular/
│   │   └── page.tsx        ← პოპულარული
│   ├── top-rated/
│   │   └── page.tsx        ← საუკეთესო
│   ├── upcoming/
│   │   └── page.tsx        ← მალე
│   └── search/
│       └── page.tsx        ← ძიება
├── .env.local.example
├── next.config.js
├── tailwind.config.ts
├── vercel.json
└── package.json
```

## 🛠 ტექნოლოგიები

| ტექნოლოგია | გამოყენება |
|---|---|
| Next.js 14 | Framework (App Router) |
| TypeScript | Type safety |
| Tailwind CSS | სტილები |
| TMDB API | ფილმების მონაცემები |
| Vercel | Hosting |

## 🎨 დიზაინი

- **ფერები**: კინემატოგრაფიული შავი + ოქროსფერი
- **ფონტები**: Playfair Display (display) + DM Sans (body)
- **ანიმაციები**: Stagger fade-up, hover parallax
- **თემა**: Dark mode, cinematic aesthetic

---

TMDB-ს მონაცემები გამოიყენება [TMDB API](https://www.themoviedb.org/documentation/api) პირობების შესაბამისად.
